﻿# Weezie UI — Production React & Tailwind Component Library
Author: Enang Weezie (https://weezie.site)
License: Commercial Royalty-Free License (Included below)

## Overview
Weezie UI is a collection of production-ready, copy-paste React + Tailwind CSS components inspired by the web's best design curation sites (VibePrompts, Minimal Gallery, Kage Design, Refero, DESIGN.md & Mobbin).

- Zero external package dependencies (pure React + Tailwind CSS)
- Fully accessible keyboard navigation and semantic HTML
- Fully responsive across desktop, tablet, and mobile
- Self-contained single-file architecture

## Quick Setup
1. Ensure your project has Tailwind CSS (v3 or v4) installed.
2. Drop any component file from ./components/ directly into your project's components/ui/ directory.
3. Import and use directly in your React / Next.js / Vite application:

`jsx
import BentoFeatures from './components/ui/BentoFeatures'

export default function MyPage() {
  return <BentoFeatures />
}
`

## Commercial License
You are granted a non-exclusive, perpetual, worldwide license to use, modify, and integrate these components in unlimited personal, commercial, and client projects. Reselling or distributing this library as a standalone UI component kit is prohibited.
